// SPDX-FileCopyrightText: 2024 Manuel Schneider
// SPDX-License-Identifier: MIT

#pragma once
namespace albert
{
static const char * const ALBERT_VERSION_STRING = "35.1.0";
static const int ALBERT_VERSION_MAJOR = 35;
static const int ALBERT_VERSION_MINOR = 1;
static const int ALBERT_VERSION_PATCH = 0;
}
